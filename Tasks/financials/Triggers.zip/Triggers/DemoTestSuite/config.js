module.exports = {
  URI: 'mongodb+srv://$z/?retryWrites=true&w=majority&appName=TriggerTester',
  SOURCE_DB: 'db1',
  SOURCE_COLLECTION: 'coll1',
  DEST_DB: 'db2',
  DEST_COLLECTION: 'coll1'
};


