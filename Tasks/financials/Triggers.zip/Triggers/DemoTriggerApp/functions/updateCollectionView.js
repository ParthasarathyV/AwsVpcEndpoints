exports = async function(changeEvent) {
  const op = changeEvent.operationType;
  const docId = changeEvent.documentKey?._id;
  const fullDoc = changeEvent.fullDocument;
  const sourceDB = changeEvent.ns?.db;
  const sourceColl = changeEvent.ns?.coll;

  console.log(`Trigger Event: op=${op}, db=${sourceDB}, coll=${sourceColl}, _id=${docId}`);

  if (sourceDB !== "db1" || sourceColl !== "coll1") {
    console.warn("Unexpected source. Skipping.");
    return;
  }

  const targetColl = context.services.get("mongodb-atlas")
                      .db("db2")
                      .collection("coll1");

  if (["insert", "update", "replace"].includes(op)) {
    if (!docId || !fullDoc) {
      console.warn("Missing docId or fullDoc.");
      return;
    }
    await targetColl.replaceOne({ _id: docId }, fullDoc, { upsert: true });
    console.log(`Synced doc: ${docId}`);
  } else if (op === "delete") {
    if (!docId) return;
    await targetColl.deleteOne({ _id: docId });
    console.log(`Deleted doc: ${docId}`);
  } else {
    console.log(`Unhandled op type: ${op}`);
  }
};

// Change Stream
