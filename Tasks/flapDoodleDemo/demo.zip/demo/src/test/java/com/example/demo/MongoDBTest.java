package com.example.demo;

import com.example.demo.model.Person;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import static org.junit.jupiter.api.Assertions.*;

@DataMongoTest
@ExtendWith(SpringExtension.class)
@TestPropertySource(properties = {
    "de.flapdoodle.mongodb.embedded.version=5.0.5"
})
class MongoDBTest {
    @Autowired
    private MongoTemplate mongoTemplate;

    @Test
    void testBasicCRUDOperations() {
        // Create
        Person person = new Person("John", "Doe", 30, "john.doe@example.com");
        mongoTemplate.save(person);
        assertNotNull(person.getId());

        // Read
        Person found = mongoTemplate.findById(person.getId(), Person.class);
        assertNotNull(found);
        assertEquals("John", found.getFirstName());
        assertEquals("Doe", found.getLastName());
        assertEquals(30, found.getAge());
        assertEquals("john.doe@example.com", found.getEmail());

        // Update
        found.setAge(31);
        found.setEmail("john.doe.updated@example.com");
        mongoTemplate.save(found);
        Person updated = mongoTemplate.findById(found.getId(), Person.class);
        assertEquals(31, updated.getAge());
        assertEquals("john.doe.updated@example.com", updated.getEmail());

        // Delete
        mongoTemplate.remove(updated);
        Person deleted = mongoTemplate.findById(updated.getId(), Person.class);
        assertNull(deleted);
    }
} 