package net.jpmchase.imedia.metadata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImediaMetadataServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(ImediaMetadataServiceApplication.class, args);
    }
}
