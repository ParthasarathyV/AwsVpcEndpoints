package net.jpmchase.imedia.metadata.model;

public class Attribute {

    private String key; // The attribute key
    private String value; // The attribute value

    // Getters and Setters

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
