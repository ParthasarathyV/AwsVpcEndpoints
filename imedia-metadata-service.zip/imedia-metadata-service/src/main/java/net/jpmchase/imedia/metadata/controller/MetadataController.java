package net.jpmchase.imedia.metadata.controller;

import net.jpmchase.imedia.metadata.model.MetadataDocument;
import net.jpmchase.imedia.metadata.service.MetadataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class MetadataController {

    @Autowired
    private MetadataService service;

    @QueryMapping
    public List<MetadataDocument> getAllMetadata() {
        return service.getAllMetadata();
    }

    @QueryMapping
    public Optional<MetadataDocument> getMetadataById(@Argument String id) {
        return service.getMetadataById(id);
    }

    @MutationMapping
    public MetadataDocument saveMetadata(@Argument MetadataDocument document) {
        return service.saveMetadata(document);
    }

    @MutationMapping
    public void deleteMetadata(@Argument String id) {
        service.deleteMetadataById(id);
    }
}
