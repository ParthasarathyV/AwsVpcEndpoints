package net.jpmchase.imedia.metadata.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;
import java.util.List;

@Document(collection = "insights")
public class Insight {

    @Id
    private String insightId; // Auto generated GUID
    private String insightType; // measure | category | score
    private Date retainUntilDt; // Flexible insight retention
    private String insightSrc;
    private String srcAnlContId;
    private String srcAnlSrvrId;
    private String srcAnlTenantId;
    private List<InsightItem> insightItems; // List of insight items
    private String s3Url; // S3 URL where the recording data is stored

    // Getters and Setters

    public String getInsightId() {
        return insightId;
    }

    public void setInsightId(String insightId) {
        this.insightId = insightId;
    }

    public String getInsightType() {
        return insightType;
    }

    public void setInsightType(String insightType) {
        this.insightType = insightType;
    }

    public Date getRetainUntilDt() {
        return retainUntilDt;
    }

    public void setRetainUntilDt(Date retainUntilDt) {
        this.retainUntilDt = retainUntilDt;
    }

    public String getInsightSrc() {
        return insightSrc;
    }

    public void setInsightSrc(String insightSrc) {
        this.insightSrc = insightSrc;
    }

    public String getSrcAnlContId() {
        return srcAnlContId;
    }

    public void setSrcAnlContId(String srcAnlContId) {
        this.srcAnlContId = srcAnlContId;
    }

    public String getSrcAnlSrvrId() {
        return srcAnlSrvrId;
    }

    public void setSrcAnlSrvrId(String srcAnlSrvrId) {
        this.srcAnlSrvrId = srcAnlSrvrId;
    }

    public String getSrcAnlTenantId() {
        return srcAnlTenantId;
    }

    public void setSrcAnlTenantId(String srcAnlTenantId) {
        this.srcAnlTenantId = srcAnlTenantId;
    }

    public List<InsightItem> getInsightItems() {
        return insightItems;
    }

    public void setInsightItems(List<InsightItem> insightItems) {
        this.insightItems = insightItems;
    }

    public String getS3Url() {
        return s3Url;
    }

    public void setS3Url(String s3Url) {
        this.s3Url = s3Url;
    }
}
