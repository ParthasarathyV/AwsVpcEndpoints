package net.jpmchase.imedia.metadata.service;

import net.jpmchase.imedia.metadata.model.MetadataDocument;
import net.jpmchase.imedia.metadata.repository.MetadataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MetadataService {

    @Autowired
    private MetadataRepository repository;

    public List<MetadataDocument> getAllMetadata() {
        return repository.findAll();
    }

    public Optional<MetadataDocument> getMetadataById(String id) {
        return repository.findById(id);
    }

    public MetadataDocument saveMetadata(MetadataDocument document) {
        return repository.save(document);
    }

    public void deleteMetadataById(String id) {
        repository.deleteById(id);
    }
}
