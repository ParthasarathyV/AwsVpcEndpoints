package net.jpmchase.imedia.metadata.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.UUID;

@Document(collection = "metadata")
public class MetadataDocument {

    @Id
    private String id = UUID.randomUUID().toString();

    private String intSrc;
    private String srcIntId;
    private String srcIntLegId;
    private List<MetadataItem> metadataItems;
    private String mediaSrc;
    private String srcMediaStreamer;
    private String srcMediaId;
    private String srcMediaUrl;
    private List<Insight> insights;
    private List<Transcript> transcripts;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIntSrc() {
        return intSrc;
    }

    public void setIntSrc(String intSrc) {
        this.intSrc = intSrc;
    }

    public String getSrcIntId() {
        return srcIntId;
    }

    public void setSrcIntId(String srcIntId) {
        this.srcIntId = srcIntId;
    }

    public String getSrcIntLegId() {
        return srcIntLegId;
    }

    public void setSrcIntLegId(String srcIntLegId) {
        this.srcIntLegId = srcIntLegId;
    }

    public List<MetadataItem> getMetadataItems() {
        return metadataItems;
    }

    public void setMetadataItems(List<MetadataItem> metadataItems) {
        this.metadataItems = metadataItems;
    }

    public String getMediaSrc() {
        return mediaSrc;
    }

    public void setMediaSrc(String mediaSrc) {
        this.mediaSrc = mediaSrc;
    }

    public String getSrcMediaStreamer() {
        return srcMediaStreamer;
    }

    public void setSrcMediaStreamer(String srcMediaStreamer) {
        this.srcMediaStreamer = srcMediaStreamer;
    }

    public String getSrcMediaId() {
        return srcMediaId;
    }

    public void setSrcMediaId(String srcMediaId) {
        this.srcMediaId = srcMediaId;
    }

    public String getSrcMediaUrl() {
        return srcMediaUrl;
    }

    public void setSrcMediaUrl(String srcMediaUrl) {
        this.srcMediaUrl = srcMediaUrl;
    }

    public List<Insight> getInsights() {
        return insights;
    }

    public void setInsights(List<Insight> insights) {
        this.insights = insights;
    }

    public List<Transcript> getTranscripts() {
        return transcripts;
    }

    public void setTranscripts(List<Transcript> transcripts) {
        this.transcripts = transcripts;
    }

    // Inner classes for MetadataItem, Insight, Transcript, etc.
}
