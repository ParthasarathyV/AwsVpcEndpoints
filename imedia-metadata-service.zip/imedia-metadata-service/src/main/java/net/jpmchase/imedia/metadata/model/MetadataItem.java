package net.jpmchase.imedia.metadata.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "metadata_items")
public class MetadataItem {

    @Id
    private String mdlItemId; // Auto generated GUID
    private String group; // Composite Int Md Item Key Index – Order 3
    private List<Attribute> attributes; // Dynamic metadata attributes

    // Getters and Setters

    public String getMdlItemId() {
        return mdlItemId;
    }

    public void setMdlItemId(String mdlItemId) {
        this.mdlItemId = mdlItemId;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }
}
