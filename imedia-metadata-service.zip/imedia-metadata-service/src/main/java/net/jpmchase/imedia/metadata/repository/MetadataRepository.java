package net.jpmchase.imedia.metadata.repository;

import net.jpmchase.imedia.metadata.model.MetadataDocument;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MetadataRepository extends MongoRepository<MetadataDocument, String> {
}
