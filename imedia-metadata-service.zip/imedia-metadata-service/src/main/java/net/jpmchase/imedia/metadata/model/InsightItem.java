package net.jpmchase.imedia.metadata.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "insight_items")
public class InsightItem {

    @Id
    private String insItemId; // Auto generated GUID
    private String group; // Composite Insight Item Key Index – Order 3
    private List<Attribute> attributes; // Dynamic insight item attributes
    private String s3Url; // S3 URL where the insight data is stored

    // Getters and Setters

    public String getInsItemId() {
        return insItemId;
    }

    public void setInsItemId(String insItemId) {
        this.insItemId = insItemId;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public List<Attribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<Attribute> attributes) {
        this.attributes = attributes;
    }

    public String getS3Url() {
        return s3Url;
    }

    public void setS3Url(String s3Url) {
        this.s3Url = s3Url;
    }
}
